import React from 'react';
import '../styles/footer.css';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const handleNavLinkClick = (e, id) => {
    e.preventDefault();
    
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({
        behavior: 'smooth'
      });
    }
  };

  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-logo">
            <span>RISHI PRASAD</span>
          </div>
          <div className="footer-links">
            <h4>Quick Links</h4>
            <ul>
              <li><a href="#hero" onClick={(e) => handleNavLinkClick(e, 'hero')}>About</a></li>
              <li><a href="#skills" onClick={(e) => handleNavLinkClick(e, 'skills')}>Skills</a></li>
              <li><a href="#projects" onClick={(e) => handleNavLinkClick(e, 'projects')}>Projects</a></li>
              <li><a href="#experience" onClick={(e) => handleNavLinkClick(e, 'experience')}>Experience</a></li>
              <li><a href="#contact" onClick={(e) => handleNavLinkClick(e, 'contact')}>Contact</a></li>
            </ul>
          </div>
          <div className="footer-social">
            <h4>Connect With Me</h4>
            <div className="social-links">
              <a href="https://linkedin.com/in/rishi-prasad-6526a7213" target="_blank" rel="noopener noreferrer">
                LinkedIn
              </a>
              <a href="https://github.com" target="_blank" rel="noopener noreferrer">
                GitHub
              </a>
            </div>
          </div>
        </div>
        <div className="footer-bottom">
          <p>&copy; {currentYear} Rishi Prasad. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;