import React from 'react';
import '../styles/skills.css';
import TagSphere from './TagSphere';

const Skills = () => {
  // Skills with their logo URLs
  const skills = [
    { 
      name: 'Java', 
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/java/java-original.svg'
    },
    { 
      name: 'Python',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/python/python-original.svg'
    },
    { 
      name: 'C++',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/cplusplus/cplusplus-original.svg'
    },
    { 
      name: 'JavaScript',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/javascript/javascript-original.svg'
    },
    { 
      name: 'HTML',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/html5/html5-original.svg'
    },
    { 
      name: 'CSS',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/css3/css3-original.svg'
    },
    { 
      name: 'ReactJS',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/react/react-original.svg'
    },
    { 
      name: 'Spring Boot',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/spring/spring-original.svg'
    },
    { 
      name: 'MongoDB',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/mongodb/mongodb-original.svg'
    },
    { 
      name: 'PostgreSQL',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/postgresql/postgresql-original.svg'
    },
    { 
      name: 'Azure',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/azure/azure-original.svg'
    },
    { 
      name: 'GitHub',
      logoUrl: 'https://cdn.jsdelivr.net/gh/devicons/devicon/icons/github/github-original.svg'
    },
    { 
      name: 'Microservices',
      logoUrl: 'https://img.icons8.com/external-flaticons-flat-flat-icons/64/external-microservices-agile-flaticons-flat-flat-icons.png'
    },
    { 
      name: 'REST API',
      logoUrl: 'https://img.icons8.com/external-flaticons-lineal-color-flat-icons/64/external-api-mobile-app-development-flaticons-lineal-color-flat-icons-4.png'
    },
    { 
      name: 'OOP',
      logoUrl: 'https://img.icons8.com/external-flaticons-lineal-color-flat-icons/64/external-object-oriented-programming-computer-science-flaticons-lineal-color-flat-icons.png'
    }
  ];
  
  const certifications = [
    {
      name: 'Microsoft Azure Fundamentals (AZ-900)',
      provider: 'Microsoft',
      logo: 'https://images.credly.com/images/be8fcaeb-c769-4858-b567-ffaaa73ce8cf/image.png'
    },
    {
      name: 'Microsoft Azure Developer Associate (AZ-204)',
      provider: 'Microsoft',
      logo: 'https://images.credly.com/images/63316b60-f62d-4e51-aacc-c23cb850089c/azure-developer-associate-600x600.png'
    }
  ];

  return (
    <section id="skills" className="skills">
      <div className="container">
        <div className="section-title">
          <h2>Skills & Expertise</h2>
        </div>
        
        {/* Tag Sphere Skills Display */}
        <TagSphere tags={skills} />
        
        {/* Fallback for mobile */}
        <div className="skills-grid-fallback">
          <h3 className="skills-fallback-title">Technical Skills</h3>
          <div className="skills-fallback-container">
            {skills.map((skill, index) => (
              <div key={index} className="skill-item-fallback">
                <div className="skill-icon-fallback">
                  <img 
                    src={skill.logoUrl} 
                    alt={skill.name} 
                    className="skill-logo-fallback" 
                  />
                </div>
                <span>{skill.name}</span>
              </div>
            ))}
          </div>
        </div>
        
        {/* Certifications with actual logos */}
        <div className="certifications-section">
          <h3>Certifications</h3>
          <div className="certification-container">
            {certifications.map((cert, index) => (
              <div key={index} className="certification-card">
                <div className="cert-icon">
                  <img src={cert.logo} alt={cert.name} className="cert-logo" />
                </div>
                <div className="cert-details">
                  <h4>{cert.name}</h4>
                  <p>{cert.provider}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;