import React, { useEffect, useRef } from 'react';
import '../styles/hero.css';
import profilePic from '../assets/profile.png';

const Hero = () => {
  const canvasRef = useRef(null);
  
  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    let particlesArray = [];
    let animationFrameId;
    
    // Set canvas size
    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    
    window.addEventListener('resize', resizeCanvas);
    resizeCanvas();
    
    // Mouse position
    const mouse = {
      x: null,
      y: null,
      radius: 100
    };
    
    window.addEventListener('mousemove', (event) => {
      mouse.x = event.x;
      mouse.y = event.y;
    });
    
    window.addEventListener('click', () => {
      // Add extra particles on click
      for (let i = 0; i < 15; i++) {
        particlesArray.push(new Particle(
          mouse.x,
          mouse.y,
          Math.random() * 2 + 1,
          getRandomColor(),
          Math.random() * 2 - 1,
          Math.random() * 2 - 1
        ));
      }
    });
    
    // Create particle class
    class Particle {
      constructor(x, y, size, color, speedX, speedY) {
        this.x = x;
        this.y = y;
        this.size = size;
        this.color = color;
        this.speedX = speedX;
        this.speedY = speedY;
        this.alpha = 1;
      }
      
      draw() {
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2);
        ctx.fillStyle = this.color;
        ctx.globalAlpha = this.alpha;
        ctx.fill();
      }
      
      update() {
        this.x += this.speedX;
        this.y += this.speedY;
        
        // Fade out slowly
        if (this.alpha > 0.02) {
          this.alpha -= 0.01;
        }
        
        this.draw();
      }
    }
    
    // Get random color in primary purple scheme
    function getRandomColor() {
      const purples = [
        'rgba(67, 24, 209, 0.5)', // Primary
        'rgba(100, 70, 220, 0.5)', // Lighter
        'rgba(50, 10, 180, 0.5)'   // Darker
      ];
      return purples[Math.floor(Math.random() * purples.length)];
    }
    
    // Create initial particles
    function init() {
      particlesArray = [];
      const numberOfParticles = Math.floor(canvas.width * canvas.height / 10000);
      for (let i = 0; i < numberOfParticles; i++) {
        const size = Math.random() * 3 + 1;
        const x = Math.random() * canvas.width;
        const y = Math.random() * canvas.height;
        const color = getRandomColor();
        const speedX = Math.random() * 0.5 - 0.25;
        const speedY = Math.random() * 0.5 - 0.25;
        particlesArray.push(new Particle(x, y, size, color, speedX, speedY));
      }
    }
    
    // Animation
    function animate() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      particlesArray.forEach((particle, index) => {
        particle.update();
        
        // Remove faded particles
        if (particle.alpha <= 0.05) {
          particlesArray.splice(index, 1);
        }
      });
      
      // Keep particle count consistent
      if (particlesArray.length < 100) {
        const newSize = Math.random() * 3 + 1;
        const newX = Math.random() * canvas.width;
        const newY = Math.random() * canvas.height;
        particlesArray.push(new Particle(
          newX,
          newY,
          newSize,
          getRandomColor(),
          Math.random() * 0.5 - 0.25,
          Math.random() * 0.5 - 0.25
        ));
      }
      
      animationFrameId = requestAnimationFrame(animate);
    }
    
    init();
    animate();
    
    // Cleanup
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      window.removeEventListener('mousemove', () => {});
      window.removeEventListener('click', () => {});
      cancelAnimationFrame(animationFrameId);
    };
  }, []);
  
  return (
    <section id="hero" className="hero">
      <canvas ref={canvasRef} className="hero-canvas"></canvas>
        <div className="container hero-container">
        <div className="hero-content">
            <h1 className="animated-text">Hello, I'm <span>Rishi Prasad</span></h1>
            <h2 className="animated-text delay-1">Software Engineer</h2>
            <p className="animated-text delay-2">
            With over 2 years of experience in Java, Spring, and microservices. I specialize in building scalable solutions and have a strong foundation in analytical thinking, communication, and problem-solving. I'm detail-oriented, collaborative, self-motivated, and passionate about continuous learning and innovation.
            </p>
            <div className="hero-buttons animated-text delay-3">
            <a 
                href="#contact" 
                className="btn btn-primary"
                onClick={(e) => {
                e.preventDefault();
                document.getElementById('contact').scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start'
                });
                }}
            >
                Get In Touch
            </a>
            <a 
                href="#projects" 
                className="btn btn-outline"
                onClick={(e) => {
                e.preventDefault();
                document.getElementById('projects').scrollIntoView({ 
                    behavior: 'smooth',
                    block: 'start' 
                });
                }}
            >
                View Projects
            </a>
            </div>
        </div>
        <div className="hero-image">
            <div className="profile-container">
            <img src={profilePic} alt="Rishi Prasad" className="profile-pic" />
            </div>
        </div>
        </div>
    </section>
  );
};

export default Hero;