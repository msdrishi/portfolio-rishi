import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';

// Components
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import Skills from './components/Skills';
import Projects from './components/Projects';
import Experience from './components/Experience';
import Contact from './components/Contact';
import Footer from './components/Footer';
import ScrollToTop from './components/ScrollToTop';

// Styles
import './styles/global.css';

const App = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    setTimeout(() => {
      setIsLoading(false);
    }, 1000);
  }, []);

  return (
    <>
      <Helmet>
        <title>Rishi Prasad | Software Engineer</title>
        <meta name="description" content="Portfolio of Rishi Prasad, a Software Engineer with over 2 years experience in Java, Spring, and microservices." />
        <meta name="keywords" content="Rishi Prasad, Software Engineer, Java, Spring, Microservices, React, Portfolio" />
      </Helmet>
      
      <div className={`app-container ${isLoading ? 'loading' : 'loaded'}`}>
        <Navbar />
        <main>
          <Hero />
          <Skills />
          <Projects />
          <Experience />
          <Contact />
        </main>
        <Footer />
        <ScrollToTop />
      </div>
    </>
  );
};

export default App;